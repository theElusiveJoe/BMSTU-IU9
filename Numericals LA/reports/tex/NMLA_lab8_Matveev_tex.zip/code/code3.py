def test(N):
    A = gen_matrix(N,N, -1,1, True)
    x = np.random.rand(N)
    b = mat_vec_product(A, x)

    x_gauss = gaussian(A, b)
    x_lib = np.linalg.solve(A,b)
    diff_gauss = norm(x - x_gauss)
    diff_lib = norm(x - x_lib)
    print('diff_gauss:', diff_gauss)
    print('diff_lib:  ', diff_lib)