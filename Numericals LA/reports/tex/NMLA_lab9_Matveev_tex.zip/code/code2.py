def input_matrix():
    a, b = int(input()), int(input())
    A = np.zeros((a,b))
    for i in range(a):
        for j in range(b):
            A[i,j] = float(input())

    return A

def gen_matrix(n,m,a=0, b=1, diag=False):
    A = np.random.rand(n,m)
    A *= b-a
    A += a
    
    if diag:
        if n != m:
            raise RuntimeError(f'диагональное преобладание возможно только у квадратных матриц')

        for i in range(n):
            A[i,i] = (sum(abs(A[i])) + abs(A[i,i])) * (-1 if np.random.choice([True, False]) else 1)

    return A